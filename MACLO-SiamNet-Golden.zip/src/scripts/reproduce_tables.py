import argparse, os, pandas as pd
def main(tables_dir):
    outs = []
    for name in ["seg_metrics.csv","cls_metrics.csv","age_metrics.csv","table_ablation.csv"]:
        p = os.path.join(tables_dir, name)
        if os.path.exists(p):
            outs.append(pd.read_csv(p))
    if outs:
        out = pd.concat(outs, axis=1)
        out.to_csv(os.path.join(tables_dir, "summary.csv"), index=False)
        print("[OK] wrote", os.path.join(tables_dir, "summary.csv"))
    else:
        print("[WARN] no tables found to summarize")
if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--tables", required=True)
    a=ap.parse_args(); main(a.tables)
