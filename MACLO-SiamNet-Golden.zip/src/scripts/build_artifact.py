import os, shutil, argparse
def main(out):
    os.makedirs(out, exist_ok=True)
    if os.path.exists("results/tables"):
        shutil.copytree("results/tables", os.path.join(out, "tables"), dirs_exist_ok=True)
    if os.path.exists("results/figures"):
        shutil.copytree("results/figures", os.path.join(out, "figures"), dirs_exist_ok=True)
    if os.path.exists("checkpoints/best.pt"):
        os.makedirs(os.path.join(out, "checkpoints"), exist_ok=True)
        shutil.copy("checkpoints/best.pt", os.path.join(out, "checkpoints/best.pt"))
    with open(os.path.join(out, "README_ARTIFACT.txt"), "w") as f:
        f.write("This folder contains the final artifacts (tables, figures, optional checkpoint).\n")
    print("[OK] artifact assembled at", out)
if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    a = ap.parse_args(); main(a.out)
