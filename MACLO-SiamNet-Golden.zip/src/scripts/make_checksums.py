import os, argparse, hashlib
def sha256_file(p):
    h = hashlib.sha256()
    with open(p,"rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()
def main(src, out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as w:
        for root, _, files in os.walk(src):
            for fn in files:
                p = os.path.join(root, fn)
                w.write(f"{sha256_file(p)}  {p}\n")
    print("[OK] checksums ->", out)
if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(); main(a.src, a.out)
