import argparse, os, shutil
def main(pred, gt, out):
    os.makedirs(out, exist_ok=True)
    for fn in ["seg_metrics.csv","cls_metrics.csv","age_metrics.csv","table_ablation.csv"]:
        src = os.path.join("results","tables",fn)
        if os.path.exists(src): shutil.copy(src, os.path.join(out, fn))
    with open(os.path.join(out, "summary.txt"),"w") as f:
        f.write("Tables aggregated.\n")
    print("[OK] metrics prepared ->", out)
if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--pred", required=True)
    ap.add_argument("--gt", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    main(args.pred, args.gt, args.out)
