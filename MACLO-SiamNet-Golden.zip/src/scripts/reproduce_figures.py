import argparse, os, pandas as pd
import matplotlib.pyplot as plt
import numpy as np

def main(tables_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    seg = pd.read_csv(os.path.join(tables_dir,"seg_metrics.csv"))
    plt.figure()
    plt.bar(["DSC"], [seg["DSC"].iloc[0]])
    plt.title("Segmentation DSC (demo)")
    plt.savefig(os.path.join(out_dir,"seg_dsc.png"))
    plt.close()

    cm = np.array([[60, 5],[7, 58]])
    plt.figure()
    plt.imshow(cm, cmap="gray")
    plt.title("Confusion Matrix (demo)")
    plt.colorbar()
    plt.savefig(os.path.join(out_dir,"confusion_matrix.png"))
    plt.close()

    print("[OK] figures saved ->", out_dir)

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--tables", required=True)
    ap.add_argument("--out", required=True)
    a=ap.parse_args(); main(a.tables, a.out)
