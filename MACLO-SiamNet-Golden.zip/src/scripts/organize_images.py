import os, csv, argparse, random, json

def detect_paths(case_dir):
    mri = None; ct=None; mask=None; cls=None; age=None; meta=None
    for fn in os.listdir(case_dir):
        l = fn.lower()
        fp = os.path.join(case_dir, fn)
        if   l.startswith("mri") and (l.endswith(".png") or l.endswith(".jpg") or l.endswith(".jpeg") or l.endswith(".dcm")): mri = fp
        elif l.startswith("ct")  and (l.endswith(".png") or l.endswith(".jpg") or l.endswith(".jpeg") or l.endswith(".dcm")): ct = fp
        elif l.startswith("mask") and (l.endswith(".png") or l.endswith(".jpg") or l.endswith(".jpeg")): mask = fp
        elif l.startswith("cls") and l.endswith(".txt"): cls = open(fp).read().strip()
        elif l.startswith("age") and l.endswith(".txt"): age = open(fp).read().strip()
        elif l.startswith("meta") and l.endswith(".json"): meta = fp
    return mri, ct, mask, cls if cls else "", age if age else "", meta if meta else ""

def main(root, train, val, test, out):
    cases = [os.path.join(root, d) for d in os.listdir(root) if os.path.isdir(os.path.join(root,d))]
    random.seed(42); random.shuffle(cases)
    n = len(cases)
    n_tr = int(train*n); n_va = int(val*n)
    splits = [("train", cases[:n_tr]), ("val", cases[n_tr:n_tr+n_va]), ("test", cases[n_tr+n_va:])]
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["split","case_id","mri_path","ct_path","mask_path","cls_label","age_hours","meta_path"])
        for sp, arr in splits:
            for cdir in arr:
                mri, ct, mask, cls, age, meta = detect_paths(cdir)
                if not mri or not ct:
                    print("[WARN] skip: missing MRI/CT in", cdir); continue
                w.writerow([sp, os.path.basename(cdir), mri, ct, mask if mask else "", cls, age, meta])
    print("[OK] wrote splits CSV ->", out)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--train", type=float, default=0.7)
    ap.add_argument("--val", type=float, default=0.15)
    ap.add_argument("--test", type=float, default=0.15)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(); main(a.root, a.train, a.val, a.test, a.out)
