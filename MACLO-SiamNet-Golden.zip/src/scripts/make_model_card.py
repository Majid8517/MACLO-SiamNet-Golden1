import os, argparse, datetime

TEMPLATE = """# Model Card — MACLO-SiamNet (Golden Pack)
**Claim:** competitive with SOTA in accuracy while superior in efficiency and multi-task capability.

## Intended use
AIS segmentation, stroke classification, and lesion-age estimation on MRI+CT 2D representatives.

## Datasets
User-supplied images (PNG/JPG or DICOM).

## Metrics
Seg: DSC/HD/ASSD; Cls: AUC/Acc/F1; Age: R2/MAE/RMSE.

## Limitations
- Demo code uses lightweight approximations of some kernels.
- Results depend on user data quality and representativeness.

## Ethical considerations
Clinical decisions must always be confirmed by specialists.

Generated: {now}
Git commit: (fill after pushing to GitHub)
"""

def main(out):
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, "w") as f:
        f.write(TEMPLATE.format(now=datetime.datetime.now().isoformat()))
    print("[OK] model card ->", out)

if __name__=="__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    a = ap.parse_args(); main(a.out)
